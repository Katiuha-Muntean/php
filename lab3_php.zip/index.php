<?php
require_once 'function.php';
$images = loadImages();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Каталог мебели</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Каталог мебели</h1>
    <div class="gallery">
        <?php foreach ($images as $image): ?>
            <div class="item">
                <img src="<?= $image['path'] ?>" alt="<?= $image['name'] ?>">
                <h3><?= $image['name'] ?></h3>
                <p><?= $image['description'] ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
